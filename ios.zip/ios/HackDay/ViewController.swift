//
//  ViewController.swift
//  HackDay
//
//  Created by Calvin Moon on 7/15/15.
//  Copyright © 2015 Calvin Moon. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate, UIGestureRecognizerDelegate {
    @IBOutlet var dangerButton: UIButton!

    @IBOutlet var coordinates: UILabel!
    @IBOutlet var radiusLabel: UILabel!
    
    @IBOutlet var stepper: UIStepper!
    
    var manager:CLLocationManager!
    var myLocations: [CLLocation] = []
    var currentLocation = true
    var setLocation = false
    
    var latitude = 0.0
    var longitude = 0.0
    
    
    @IBOutlet var myMap: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var longPress = UILongPressGestureRecognizer(target: self, action: "setPin:")
        self.myMap.addGestureRecognizer(longPress)
        
        
        var currentLocButton = MKUserTrackingBarButtonItem(mapView: self.myMap)
        self.navigationItem.leftBarButtonItem = currentLocButton;
        
        self.dangerButton.layer.borderColor = UIColor(red: 21.0/256.0, green: 126.0/256.0, blue: 251.0/256.0, alpha: 1.0).CGColor
        self.dangerButton.layer.cornerRadius = 5;
        self.dangerButton.clipsToBounds = true;
        
        self.stepper.minimumValue = 0.05
        self.stepper.maximumValue = 0.3
        self.stepper.stepValue = 0.05
        self.stepper.value = 0.05
        self.radiusLabel.text = "Radius: " + "\(self.stepper.value)"
        
        myMap.delegate = self
        myMap.showsUserLocation = true
        

        
        
        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.startUpdatingLocation()
//        print("manager loaded")
//        var data = NSData(contentsOfURL: NSURL(string: "https://data.cityofchicago.org/resource/ijzp-q8t2.json?$limit=50000&$where=within_circle(location,41.89,-87.73,100)")!)
//        let json = JSON(data: data!)
//        print("dictionary")
//        print(json)

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        
        if(self.currentLocation)
        {
            let region = MKCoordinateRegionMakeWithDistance(
                manager.location!.coordinate, 400000, 400000)
            if setLocation == false
            {
                myMap.setRegion(region, animated: true)
                setLocation = true
            }
            
            self.coordinates.text = "Coordinates: "+String(format: "%.02f", locValue.latitude)+", "+String(format: "%.02f", locValue.longitude)
            self.latitude = locValue.latitude
            self.longitude = locValue.longitude
        }

    }

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        //self.didTouch = true
    }
    
    func setPin(gestureRecognizer:UIGestureRecognizer)
    {
        if (gestureRecognizer.state != UIGestureRecognizerState.Began) {
            return;
        }
        let touchPoint = gestureRecognizer.locationInView(self.myMap)
        let touchMapCoordinate = self.myMap.convertPoint(touchPoint, toCoordinateFromView: self.myMap)
        let point = MKPointAnnotation()
        point.coordinate = touchMapCoordinate
        for pin in self.myMap.annotations
        {
            self.myMap.removeAnnotation(pin)
        }
        self.myMap.addAnnotation(point)
        self.coordinates.text = "Coordinates: "+String(format: "%.02f", point.coordinate.latitude)+", "+String(format: "%.02f", point.coordinate.longitude)
        self.latitude = point.coordinate.latitude
        self.longitude = point.coordinate.longitude
        self.currentLocation = false
        
    }
    
    func mapView(mapView: MKMapView, didChangeUserTrackingMode mode: MKUserTrackingMode, animated: Bool) {
        if mode==MKUserTrackingMode.Follow
        {
            let region = MKCoordinateRegionMakeWithDistance(
                manager.location!.coordinate, 400000, 400000)
            
            myMap.setRegion(region, animated: true)
            
            for pin in self.myMap.annotations
            {
                self.myMap.removeAnnotation(pin)
            }
            
            self.currentLocation = true
        }
        
    }

    @IBAction func didSelectStepper(sender: UIStepper) {
        if self.stepper.value == 10
        {
            self.radiusLabel.text = "Radius:" + "\(self.stepper.value)"
        }
        else
        {
            self.radiusLabel.text = "Radius: " + "\(self.stepper.value)"
        }
    }
    
    @IBAction func dangerButtonPressed(sender: UIButton) {
        let kilometer = 1609.34*self.stepper.value
        var data1 = NSData(contentsOfURL: NSURL(string: "http://sfhackday2015.ngrok.com/latitude="+"\(self.latitude)"+"&longitude="+"\(self.longitude)"+"&radius="+"\(kilometer)")!)
        var response = NSString(data: data1!, encoding: NSUTF8StringEncoding) as! String
        
        var dataArray = response.componentsSeparatedByString("<br>")
        
        var message = "Statistical Danger Level: "+dataArray[2]+"%\n"+"Number of Crimes: " + dataArray[0] + "\n" + "Current Weather: " + dataArray[1]
        
        var alert = UIAlertController(title: dataArray[3], message: message, preferredStyle: UIAlertControllerStyle.Alert)
        
        alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
        
        
        
    }
}

